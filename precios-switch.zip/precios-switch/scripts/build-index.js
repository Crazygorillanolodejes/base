// Regenera netlify/functions/games.json a partir de titledb (github.com/blawar/titledb).
// Uso: node scripts/build-index.js   (necesita Node 18+; descarga ~350 MB)
const fs = require("fs"), path = require("path");
const B = "https://raw.githubusercontent.com/blawar/titledb/master/";
const FILES = {US: "US.en", GB: "GB.en", JP: "JP.ja", HK: "HK.zh", KR: "KR.ko"};
const isBase = id => /^[0-9a-f]{16}$/i.test(id) && id.endsWith("000") && parseInt(id[12], 16) % 2 === 0;
(async () => {
  const idx = {};
  for (const [reg, f] of Object.entries(FILES)) {
    console.log("Descargando", f);
    const data = await (await fetch(B + f + ".json")).json();
    for (const e of Object.values(data)) {
      if (!e || !e.id || !e.nsuId || !e.name || !isBase(e.id)) continue;
      const r = idx[e.id] ||= {i: e.id, n: [], s: {}, im: null};
      if (!r.s[reg]) r.s[reg] = String(e.nsuId);
      const name = e.name.replace(/[™®©]/g, "").replace(/\s+/g, " ").trim();
      if (name && !r.n.includes(name) && r.n.length < 4) r.n.push(name);
      if (!r.im && e.iconUrl) r.im = e.iconUrl;
    }
  }
  const out = Object.values(idx);
  fs.writeFileSync(path.join(__dirname, "../netlify/functions/games.json"), JSON.stringify(out));
  console.log("Juegos:", out.length);
})();
