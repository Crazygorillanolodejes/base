// Netlify Function: busca el juego en el índice local y consulta precios en cada tienda de Nintendo.
const GAMES = require("./games.json");
// país -> catálogo (los códigos de juego son distintos en cada catálogo)
const REG = {US:"US",CA:"US",MX:"US",BR:"US",AR:"US",CL:"US",CO:"US",PE:"US",JP:"JP",HK:"HK",TW:"HK",KR:"KR"};
"AT BE BG HR CY CZ DK EE FI FR DE GR HU IE IT LV LT LU MT NL NO PL PT RO SK SI ES SE CH GB ZA AU NZ".split(" ").forEach(c => REG[c] = "GB");

const norm = s => (s || "").toLowerCase().normalize("NFKC").normalize("NFD").replace(/[\u0300-\u036f]/g, "").normalize("NFC").replace(/[^\p{L}\p{N}]+/gu, " ").trim();
const KEYS = GAMES.map(g => g.n.map(norm));
const out = (code, obj) => ({statusCode: code, headers: {"Content-Type": "application/json"}, body: JSON.stringify(obj)});

function search(q) {
  const t = norm(q).split(" ").filter(Boolean);
  if (!t.length) return [];
  const nq = t.join(" "), hits = [];
  GAMES.forEach((g, i) => {
    let best = 0;
    for (const k of KEYS[i]) {
      if (!t.every(w => k.includes(w))) continue;
      best = Math.max(best, k === nq ? 3 : k.startsWith(nq) ? 2 : 1);
    }
    if (best) hits.push({g, best});
  });
  hits.sort((a, b) => b.best - a.best || a.g.n[0].length - b.g.n[0].length);
  return hits.slice(0, 8).map(({g}) => ({id: g.i, title: g.n[0], image: g.im}));
}

async function price(c, id) {
  const r = await fetch(`https://api.ec.nintendo.com/v1/price?country=${c}&lang=en&ids=${id}`);
  const p = (await r.json()).prices?.[0], reg = p?.regular_price;
  if (!reg) return null;
  const d = p.discount_price;
  return {c, cur: reg.currency, reg: +reg.raw_value, disc: d ? +d.raw_value : null, end: d?.end_datetime || null};
}

exports.handler = async e => {
  const {q, id} = e.queryStringParameters || {};
  try {
    if (q) return out(200, {results: search(q)});
    const g = GAMES.find(x => x.i === id);
    if (!g) return out(404, {error: "Juego no encontrado"});
    const jobs = Object.entries(REG).filter(([, r]) => g.s[r]).map(([c, r]) => price(c, g.s[r]));
    const [fx, res] = await Promise.all([
      fetch("https://open.er-api.com/v6/latest/USD").then(r => r.json()),
      Promise.allSettled(jobs)
    ]);
    const rows = res.map(r => r.value).filter(Boolean).map(r => {
      const k = fx.rates?.[r.cur], f = v => (k && v != null ? v / k : null);
      return {...r, usd: f(r.disc ?? r.reg), usdReg: f(r.reg)};
    }).filter(r => r.usd != null).sort((a, b) => a.usd - b.usd);
    return out(200, {title: g.n[0], rows});
  } catch (err) { return out(500, {error: String(err)}); }
};
